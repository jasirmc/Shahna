close all
clear all

load test1.mat %regular initial profile

figure(1)
for i=1:6:60
plot(tata(:,i),zt)
hold on
end

figure(2)
h=pcolor(time,zm,rrc)
set(h,'edgecolor','none') 



figure(3)
h=pcolor(time,zm,qs)
set(h,'edgecolor','none')
colorbar

figure(4)
h=pcolor(time,zm,rh)
set(h,'edgecolor','none')
colorbar

figure(5)
plot(time,sum(rrd))

%caxis([0 0.01])

% load test2.mat %regular initial profile
% 
% figure(4)
% for i=1:6:60
% plot(tata(:,i),zt)
% hold on
% end
% 
% figure(5)
% h=pcolor(time,zm,rrc)
% set(h,'edgecolor','none') 
% 
% 
% 
% figure(6)
% h=pcolor(time,zm,rrd)
% set(h,'edgecolor','none') 
