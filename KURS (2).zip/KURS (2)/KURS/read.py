import numpy as np

# =============================================================================
# returns array:
# [0] time    - time s
# [1] zm      - vertical mass grid [m]
# [2] zt      - Vertical turbulent grid [m]
# [3] u       - Horizontal wind component x [m/s]
# [4] v       - Horizontal wind component y [m/s]
# [5] w       - Vertical wind component [m/s]
# [6] rr      - Total water content [g/kg]
# [7] rrl     - Liquid water content [g/kg]
# [8] rrc     - Cloud fraction [1]
# [9] rrd     - Drizzle water content [g/kg]
# [10] t       - 
# [11] pii     - 
# [12] q2      - Turbulent kinetic energy [m2/s2]
# [13] l       -
# [14] fsd     - Solar radiation down [W/m2]
# [15] fsu     - Solar radiation up [W/m2]
# [16] fld     - Longwave radiation down [W/m2]
# [17] flu     - Longwave radiation up [W/m2]
# [18] sigr    - Radiative heating/cooling [K/h]
# [19] tatal   - 
# [20] tata    - Potential temperature [K]
# [21] tl      - 
# [22] tatae   - 
# [23] ppp     - Pressure [hPa]
# [24] es      - 
# [25] qs      - 
# [26] U       - Horizontal wind magnitude [m/s]
# [27] dirr    - Wind direction
# =============================================================================

# =============================================================================
# You can plot contour plot from the generated data that is located in the folder "test1" in the next way:
#
# data = readin('test1')
# x = data[0] # to get time
# y = data[1] # to get height
# z = data[6] # to get total water content
#
# And then plot a contour plot. Contact lab assistent if you have difficulties with plotting
# =============================================================================

def readin(foldername):
    
    z = np.loadtxt(foldername+'/z.dat')
    zm=z[:,1];
    zt=z[:,0];
    time=np.arange(0,48.5,0.5);


    files = [foldername+'/res{}.dat'.format(a) if a>9  else
            foldername+'/res0{}.dat'.format(a) for a in np.arange(97)]

    nk=60

#define variables
    zi_d = np.zeros_like(files)
    u = np.zeros((nk, len(files)))
    v = np.zeros((nk, len(files)))
    w = np.zeros((nk, len(files)))
    rr = np.zeros((nk, len(files)))
    rrl = np.zeros((nk, len(files)))
    rrc = np.zeros((nk, len(files)))
    rrd = np.zeros((nk, len(files)))
    t = np.zeros((nk, len(files)))
    pii = np.zeros((nk, len(files)))
    q2 = np.zeros((nk, len(files)))
    l = np.zeros((nk, len(files)))
    fsd = np.zeros((nk, len(files)))
    fsu = np.zeros((nk, len(files)))
    fld = np.zeros((nk, len(files)))
    flu = np.zeros((nk, len(files)))
    sigr = np.zeros((nk, len(files)))


    for ifile in np.arange(len(files)):
        data = np.fromfile(files[ifile],dtype = np.dtype('<f'))
        pointer = 0 # increasing this is the same as reading 1 number in the matlab shit
        pointer += 1
        zi_d[ifile] = data[pointer]
        pointer += 3
        for k in np.arange(nk):
            u[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            v[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            w[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            rr[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            rrl[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            rrc[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            rrd[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            t[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            pii[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            q2[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            l[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            fsd[k,ifile] = data[pointer]
            pointer +=1
    
        pointer += 2
        for k in np.arange(nk):
            fsu[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            fld[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            flu[k,ifile] = data[pointer]
            pointer +=1

        pointer += 2
        for k in np.arange(nk):
            sigr[k,ifile] = data[pointer]
            pointer +=1

#VARIABLE CALCULATIONS
    q2 = q2/2
    tatal = t
    tata  = tatal + 2.5e6 * rrl/ 1004.6e0 / 1000
    tl= tatal * pii / 1004.6
    t= tata * pii / 1004.6
    tatae = tata + (2.5e6*tata) / (1004.6 * t) * (rr-rrl) / 1000
    ppp= 1000 * (pii / 1004.6)**(1004.6/287.)
    es= 10**(23.5470-4.9283 * np.log10(t)-2937.4 / t)
    qs= (0.622*es / (ppp-es)) * 1000.
    U= np.sqrt(u**2+v**2)
    dir= 270.-180/ 3.141593 * np.arctan2(v,u)
    rh=rr / 1000 / (0.622*es / (ppp-es)) * 100
    
    dirr = dir
    for tt in range(97):
        for k in range(60):
            if dir[k,tt] > 360:
                dirr[k,tt] = dir[k,tt] - 360
    
    return [time, zm, zt, u, v, w, rr, rrl, rrc, rrd, t ,pii, q2, l, fsd, fsu, fld, flu, sigr, tatal, tata, tl, tatae, ppp, es, qs, U, dirr] 
